import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { DemoModule } from './Demo.module';

document.addEventListener('DOMContentLoaded', () => {
  platformBrowserDynamic()
    .bootstrapModule(DemoModule)
    .catch(err => console.error(err));
});
