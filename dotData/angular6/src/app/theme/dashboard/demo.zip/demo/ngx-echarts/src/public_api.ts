/*
 * Public API Surface of ngx-echarts
 */

export * from './lib/ngx-echarts.service';
export * from './lib/ngx-echarts.module';
