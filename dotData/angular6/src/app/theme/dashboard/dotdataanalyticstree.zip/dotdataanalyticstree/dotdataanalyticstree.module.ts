


import { NgModule } from '@angular/core';
//import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { APP_BASE_HREF, Location } from '@angular/common';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { NgxGraphModule } from './ngx-graph.module';



import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {SelectModule} from 'ng-select';
import {TagInputModule} from 'ngx-chips';
import {HttpModule, JsonpModule} from '@angular/http';
import {DxDataGridModule, DxDropDownBoxModule, DxTreeViewModule} from 'devextreme-angular';
import {  DxSelectBoxModule } from 'devextreme-angular';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//
// import { NgModule } from '@angular/core';

import { ChartCommonModule } from '@swimlane/ngx-charts';
import { MouseWheelDirective } from './mouse-wheel.directive';


import { DotdataanalyticstreeComponent } from './dotdataanalyticstree.component';
export { DotdataanalyticstreeComponent };


import {DotdataanalyticstreeRoutingModule} from './dotdataanalyticstree-routing.module';
import {SharedModule} from '../../../shared/shared.module';
import {ChartModule} from 'angular2-chartjs';


import {DxChartModule} from 'devextreme-angular';





@NgModule({
    imports: [ CommonModule, NgxChartsModule, NgxGraphModule, FormsModule,
    DxSelectBoxModule,
    DxTreeViewModule,
    DxDropDownBoxModule,

    DxDataGridModule,
    /* NgMultiSelectDropDownModule,*/
    CommonModule,
    SharedModule,
    FormsModule,
    SharedModule,
    HttpClientModule,
    HttpModule,
    ReactiveFormsModule,

    FormsModule,
    SelectModule,
    TagInputModule,
    JsonpModule,

    CommonModule,
        ChartCommonModule,
        DotdataanalyticstreeRoutingModule,
        SharedModule,
        ChartModule,
        DxChartModule,
        NgxChartsModule
    ],
    declarations: [DotdataanalyticstreeComponent, MouseWheelDirective],
    exports: [DotdataanalyticstreeComponent, MouseWheelDirective],
})
export class DotdataanalyticstreeModule { }



